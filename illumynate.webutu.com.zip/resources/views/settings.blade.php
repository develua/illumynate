@extends('layouts.app')

@section('content')
    <div class="panel-heading">Settings</div>
    <div class="panel-body">
        <p>This settings</p>
    </div>
@endsection