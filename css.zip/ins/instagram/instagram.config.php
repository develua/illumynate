<?php
// Setup class
  $instagram = new Instagram(array(
    'apiKey'      => 'c1b0ea2a268140178b70101227cc237f',
    'apiSecret'   => '30daeaa3bc6f41da90b7ec6cf856ad48',
    'apiCallback' => 'http://winnercodes.com/social.winnercodes.com/social/ins/instagram/success.php' // must point to success.php
  ));

?>